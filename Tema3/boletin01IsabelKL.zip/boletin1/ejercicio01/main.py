from trabajador import *
if __name__=="__main__":
    t1=Trabajador("Pedro")
    t2=Trabajador("Javi")
    t3=Trabajador("Luisa")
    t4=Trabajador("Paco")
    t5=Trabajador("Miguel")
    t6=Trabajador("Elena")

    t1.start()
    t2.start()
    t3.start()
    t4.start()
    t5.start()
    t6.start()








